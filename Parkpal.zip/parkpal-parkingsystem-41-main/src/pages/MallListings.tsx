import { useState } from "react";
import { Search, Car, MapPin, Clock, Zap, Shield, Filter, X, Bookmark, BookmarkX, Accessibility, Heart, Baby } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import DashboardSidebar from "@/components/DashboardSidebar";
import { useToast } from "@/hooks/use-toast";

const malls = [
  {
    id: 1,
    name: "Central Mall",
    address: "123 Main St, Downtown",
    availableSpots: 45,
    distance: "2.5",
    hasEVCharging: true,
    hasValet: true,
    hasSecurity: true,
    isBookmarked: false,
    specialSpots: {
      disabled: 8,
      elderly: 5,
      pregnant: 3,
    },
    parkingLayout: [
      { zone: "A", available: 15, total: 20 },
      { zone: "B", available: 18, total: 25 },
      { zone: "C", available: 12, total: 15 },
    ],
  },
  {
    id: 2,
    name: "WhiteField Shopping",
    address: "456 Park Avenue, Uptown",
    availableSpots: 32,
    distance: "3.8",
    hasEVCharging: false,
    hasValet: true,
    hasSecurity: true,
    specialSpots: {
      disabled: 6,
      elderly: 4,
      pregnant: 2,
    },
    parkingLayout: [
      { zone: "A", available: 10, total: 15 },
      { zone: "B", available: 12, total: 20 },
      { zone: "C", available: 10, total: 12 },
    ],
  },
  {
    id: 3,
    name: "Sarath City Capital Mall",
    address: "789 Metro Road, Midtown",
    availableSpots: 28,
    distance: "1.2",
    hasEVCharging: true,
    hasValet: false,
    hasSecurity: true,
    specialSpots: {
      disabled: 5,
      elderly: 3,
      pregnant: 2,
    },
    parkingLayout: [
      { zone: "A", available: 8, total: 12 },
      { zone: "B", available: 12, total: 18 },
      { zone: "C", available: 8, total: 10 },
    ],
  },
];

const MallListings = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMall, setSelectedMall] = useState<typeof malls[0] | null>(null);
  const [filters, setFilters] = useState({
    evCharging: false,
    valet: false,
    security: false,
  });
  const [mallsData, setMallsData] = useState(malls);
  const { toast } = useToast();

  const filteredMalls = mallsData.filter((mall) => {
    const matchesSearch = mall.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase()) ||
      mall.address.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilters = 
      (!filters.evCharging || mall.hasEVCharging) &&
      (!filters.valet || mall.hasValet) &&
      (!filters.security || mall.hasSecurity);

    return matchesSearch && matchesFilters;
  });

  const handleReservation = (mallId: number) => {
    toast({
      title: "Booking Initiated",
      description: "Please complete your parking spot reservation.",
    });
  };

  const toggleBookmark = (mallId: number) => {
    const mall = mallsData.find(m => m.id === mallId);
    
    if (mall?.isBookmarked) {
      setMallsData(prevMalls =>
        prevMalls.map(m =>
          m.id === mallId ? { ...m, isBookmarked: false } : m
        )
      );
      toast({
        title: "Mall Unbookmarked",
        description: "The mall has been removed from your saved list.",
      });
    } else {
      setMallsData(prevMalls =>
        prevMalls.map(m =>
          m.id === mallId ? { ...m, isBookmarked: true } : m
        )
      );
      toast({
        title: "Mall Bookmarked",
        description: "The mall has been added to your bookmarks.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <MapPin className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Mall Listings
          </h1>
        </div>
      </div>

      <DashboardSidebar />

      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="flex justify-between items-center gap-4">
            <div className="relative flex-1 max-w-xl">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search malls by name or location..."
                className="pl-10 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Filter className="mr-2" />
                  Filter Options
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none">
                  <X className="h-4 w-4" />
                  <span className="sr-only">Close</span>
                </DialogClose>
                <DialogHeader>
                  <DialogTitle>Filter Mall Amenities</DialogTitle>
                  <DialogDescription>
                    Select the amenities you're looking for.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.evCharging}
                      onChange={(e) =>
                        setFilters({ ...filters, evCharging: e.target.checked })
                      }
                      className="rounded border-gray-300"
                    />
                    <span>EV Charging Available</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.valet}
                      onChange={(e) =>
                        setFilters({ ...filters, valet: e.target.checked })
                      }
                      className="rounded border-gray-300"
                    />
                    <span>Valet Service</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.security}
                      onChange={(e) =>
                        setFilters({ ...filters, security: e.target.checked })
                      }
                      className="rounded border-gray-300"
                    />
                    <span>24/7 Security</span>
                  </label>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredMalls.map((mall) => (
              <Card key={mall.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-start">
                        <h3 className="text-xl font-semibold">{mall.name}</h3>
                        <button 
                          onClick={() => toggleBookmark(mall.id)}
                          className="hover:scale-110 transition-transform"
                        >
                          {mall.isBookmarked ? (
                            <Bookmark className="h-5 w-5 text-primary" />
                          ) : (
                            <BookmarkX className="h-5 w-5 text-gray-400" />
                          )}
                        </button>
                      </div>
                      <div className="flex items-center text-muted-foreground mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="text-sm">{mall.address}</span>
                      </div>
                      <div className="flex items-center text-muted-foreground mt-1">
                        <Car className="h-4 w-4 mr-1" />
                        <span className="text-sm">{mall.availableSpots} spots available</span>
                      </div>
                      <div className="flex items-center text-muted-foreground mt-1">
                        <Clock className="h-4 w-4 mr-1" />
                        <span className="text-sm">{mall.distance} km away</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {mall.hasEVCharging && (
                        <div className="bg-green-100 text-green-800 px-2 py-1 rounded-md text-xs flex items-center">
                          <Zap className="h-3 w-3 mr-1" />
                          EV
                        </div>
                      )}
                      {mall.hasValet && (
                        <div className="bg-blue-100 text-blue-800 px-2 py-1 rounded-md text-xs">
                          Valet
                        </div>
                      )}
                      {mall.hasSecurity && (
                        <div className="bg-purple-100 text-purple-800 px-2 py-1 rounded-md text-xs flex items-center">
                          <Shield className="h-3 w-3 mr-1" />
                          Security
                        </div>
                      )}
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full"
                          onClick={() => setSelectedMall(mall)}
                        >
                          View Details & Reserve
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                        <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none">
                          <X className="h-4 w-4" />
                          <span className="sr-only">Close</span>
                        </DialogClose>
                        <DialogHeader>
                          <DialogTitle>{mall.name}</DialogTitle>
                          <DialogDescription>{mall.address}</DialogDescription>
                        </DialogHeader>
                        
                        <div className="grid gap-6">
                          <div>
                            <h4 className="font-medium mb-2">Parking Layout</h4>
                            <div className="grid grid-cols-3 gap-4">
                              {mall.parkingLayout.map((zone) => (
                                <div
                                  key={zone.zone}
                                  className="bg-secondary p-4 rounded-lg text-center"
                                >
                                  <div className="text-lg font-semibold">
                                    Zone {zone.zone}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {zone.available}/{zone.total} spots
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-2">Reserved Spots</h4>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="bg-blue-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Accessibility className="h-4 w-4" />
                                  <span>Disabled</span>
                                </div>
                                <div className="text-sm">{mall.specialSpots.disabled} spots</div>
                              </div>
                              <div className="bg-green-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Heart className="h-4 w-4" />
                                  <span>Elderly</span>
                                </div>
                                <div className="text-sm">{mall.specialSpots.elderly} spots</div>
                              </div>
                              <div className="bg-purple-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Baby className="h-4 w-4" />
                                  <span>Pregnant</span>
                                </div>
                                <div className="text-sm">{mall.specialSpots.pregnant} spots</div>
                              </div>
                            </div>
                          </div>

                          <form className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <label className="text-sm font-medium">Date</label>
                                <Input type="date" className="w-full" />
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-medium">Time</label>
                                <Input type="time" className="w-full" />
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Vehicle Type</label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select vehicle type" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="2-wheeler">2 Wheeler</SelectItem>
                                  <SelectItem value="4-wheeler">4 Wheeler</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Special Requirements</label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select if needed" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="disabled">Disabled Parking</SelectItem>
                                  <SelectItem value="elderly">Elderly Parking</SelectItem>
                                  <SelectItem value="pregnant">Pregnant Parking</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            <Button 
                              className="w-full"
                              onClick={() => handleReservation(mall.id)}
                            >
                              Reserve Spot
                            </Button>
                          </form>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default MallListings;
