
import React, { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CalendarIcon, Pen, Settings as SettingsIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import DashboardSidebar from "@/components/DashboardSidebar";

const formSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits"),
  dateOfBirth: z.date({
    required_error: "Please select a date of birth",
  }),
  gender: z.enum(["male", "female", "other"], {
    required_error: "Please select a gender",
  }),
  fourWheelers: z.string(),
  twoWheelers: z.string(),
  vehicleNumbers: z.array(z.string()).optional(),
});

export default function Settings() {
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [vehicleFields, setVehicleFields] = useState<{
    fourWheelers: number;
    twoWheelers: number;
  }>({ fourWheelers: 0, twoWheelers: 0 });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phoneNumber: "",
      gender: "male",
      fourWheelers: "0",
      twoWheelers: "0",
      vehicleNumbers: [],
    },
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVehicleNumberChange = (value: string, type: "four" | "two") => {
    const numValue = parseInt(value);
    setVehicleFields(prev => ({
      ...prev,
      [type === "four" ? "fourWheelers" : "twoWheelers"]: numValue,
    }));
  };

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    console.log(values);
    // Handle form submission
  };

  const numberOptions = Array.from({ length: 6 }, (_, i) => i.toString());

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <SettingsIcon className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Profile Settings
          </h1>
        </div>
      </div>

      <DashboardSidebar />

      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-2xl mx-auto">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 bg-white p-6 rounded-lg shadow-sm">
              {/* Profile Picture */}
              <div className="flex flex-col items-center space-y-4 mb-8">
                <div className="relative">
                  <Avatar className="h-32 w-32">
                    <AvatarImage src={profileImage || ""} />
                    <AvatarFallback>UP</AvatarFallback>
                  </Avatar>
                  <div className="absolute bottom-0 right-0 bg-primary rounded-full p-2 cursor-pointer">
                    <label htmlFor="profile-upload" className="cursor-pointer">
                      <Pen className="h-4 w-4 text-white" />
                    </label>
                  </div>
                  <Input
                    id="profile-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Full Name */}
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your full name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Email */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Enter your email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Phone Number */}
              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input type="tel" placeholder="Enter your phone number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Date of Birth */}
              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date of Birth</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) =>
                            date > new Date() || date < new Date("1900-01-01")
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Gender */}
              <FormField
                control={form.control}
                name="gender"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Gender</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-row gap-6"
                      >
                        <FormItem className="flex items-center space-x-3">
                          <FormControl>
                            <RadioGroupItem value="male" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3">
                          <FormControl>
                            <RadioGroupItem value="female" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3">
                          <FormControl>
                            <RadioGroupItem value="other" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">Other</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Number of Vehicles */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="fourWheelers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of 4-Wheelers</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          field.onChange(value);
                          handleVehicleNumberChange(value, "four");
                        }}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select number" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {numberOptions.map((num) => (
                            <SelectItem key={num} value={num}>
                              {num}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="twoWheelers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of 2-Wheelers</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          field.onChange(value);
                          handleVehicleNumberChange(value, "two");
                        }}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select number" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {numberOptions.map((num) => (
                            <SelectItem key={num} value={num}>
                              {num}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Vehicle Registration Numbers */}
              {vehicleFields.fourWheelers > 0 && (
                <div className="space-y-4">
                  <h3 className="font-medium">4-Wheeler Registration Numbers</h3>
                  {Array.from({ length: vehicleFields.fourWheelers }).map((_, index) => (
                    <Input
                      key={`4w-${index}`}
                      placeholder={`4-Wheeler ${index + 1} Registration Number`}
                      className="w-full"
                    />
                  ))}
                </div>
              )}

              {vehicleFields.twoWheelers > 0 && (
                <div className="space-y-4">
                  <h3 className="font-medium">2-Wheeler Registration Numbers</h3>
                  {Array.from({ length: vehicleFields.twoWheelers }).map((_, index) => (
                    <Input
                      key={`2w-${index}`}
                      placeholder={`2-Wheeler ${index + 1} Registration Number`}
                      className="w-full"
                    />
                  ))}
                </div>
              )}

              <Button type="submit" className="w-full">Save Changes</Button>
            </form>
          </Form>
        </div>
      </main>
    </div>
  );
}
