
import { 
  Search, 
  Calendar,
  MapPin,
  Clock,
  Settings,
  Bookmark,
  ArrowRight,
  Mail,
  Phone,
  User
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import DashboardSidebar from "@/components/DashboardSidebar";
import { Separator } from "@/components/ui/separator";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState } from "react";
import { format } from "date-fns";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const upcomingReservation = {
  mall: "Central Mall",
  date: "2024-03-20",
  time: "14:00 - 16:00",
  spotType: "Standard",
  spot: "A-123"
};

const frequentMalls = [
  {
    name: "Central Mall",
    availability: "Available",
    spots: 150
  },
  {
    name: "WhiteField Shopping",
    availability: "Limited",
    spots: 50
  },
  {
    name: "Sarath City Capital Mall",
    availability: "Full",
    spots: 0
  }
];

const mockUser = {
  name: "John Doe",
  email: "john.doe@example.com",
  phoneNumber: "+1 234 567 8900"
};

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isModifyDialogOpen, setIsModifyDialogOpen] = useState(false);
  const [isFindParkingDialogOpen, setIsFindParkingDialogOpen] = useState(false);
  const [selectedMall, setSelectedMall] = useState("");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState("10:00 - 12:00");

  const handleCancelReservation = () => {
    toast({
      title: "Reservation Cancelled",
      description: "Your reservation has been cancelled successfully."
    });
  };

  const handleModifyReservation = () => {
    setIsModifyDialogOpen(false);
    toast({
      title: "Reservation Modified",
      description: "Your reservation has been updated successfully."
    });
  };

  const handleFindParking = (mallName: string) => {
    setSelectedMall(mallName);
    setIsFindParkingDialogOpen(true);
  };

  const handleConfirmParking = () => {
    setIsFindParkingDialogOpen(false);
    navigate("/find-parking");
  };

  const getAvailabilityColor = (status: string) => {
    switch (status) {
      case "Available":
        return "text-green-500";
      case "Limited":
        return "text-yellow-500";
      case "Full":
        return "text-red-500";
      default:
        return "text-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20 flex justify-between items-center">
        <h1 className="text-4xl font-bold tracking-tight text-white ml-8">Welcome User!</h1>
        <HoverCard>
          <HoverCardTrigger asChild>
            <Button variant="ghost" className="h-12 w-12 rounded-full">
              <Avatar>
                <AvatarFallback>
                  <User className="h-6 w-6 text-white" />
                </AvatarFallback>
              </Avatar>
            </Button>
          </HoverCardTrigger>
          <HoverCardContent className="w-64">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 opacity-70" />
                <span className="text-sm font-medium">{mockUser.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 opacity-70" />
                <span className="text-sm">{mockUser.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 opacity-70" />
                <span className="text-sm">{mockUser.phoneNumber}</span>
              </div>
            </div>
          </HoverCardContent>
        </HoverCard>
      </div>
      
      <DashboardSidebar />
      
      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="relative w-full max-w-xl">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input 
              type="search" 
              placeholder="Search malls or reservations..." 
              className="pl-10 w-full"
            />
          </div>

          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-semibold text-primary">Next Reservation</h2>
                <div className="space-x-2">
                  <Button variant="outline" onClick={handleCancelReservation}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsModifyDialogOpen(true)}>
                    Modify
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-6 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  <span>{upcomingReservation.mall} - Spot {upcomingReservation.spot}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  <span>{upcomingReservation.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  <span>{upcomingReservation.time}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold text-primary">Frequent Malls</h2>
                <Button variant="outline" onClick={() => navigate("/saved-malls")}>
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-4">
                {frequentMalls.map((mall, index) => (
                  <div key={mall.name}>
                    {index > 0 && <Separator className="my-4" />}
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <h3 className="font-semibold text-primary">{mall.name}</h3>
                        <p className={`text-sm ${getAvailabilityColor(mall.availability)}`}>
                          {mall.availability} • {mall.spots} spots
                        </p>
                      </div>
                      <Button 
                        onClick={() => handleFindParking(mall.name)}
                        disabled={mall.availability === "Full"}
                      >
                        Find Parking
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="hover:bg-secondary/50 transition-colors cursor-pointer" onClick={() => navigate("/reservations")}>
              <CardContent className="p-6 flex items-center gap-4">
                <Calendar className="h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-semibold text-primary">Reservations</h3>
                  <p className="text-sm text-muted-foreground">View and manage your bookings</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground ml-auto" />
              </CardContent>
            </Card>
            
            <Card className="hover:bg-secondary/50 transition-colors cursor-pointer" onClick={() => navigate("/saved-malls")}>
              <CardContent className="p-6 flex items-center gap-4">
                <Bookmark className="h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-semibold text-primary">Saved Malls</h3>
                  <p className="text-sm text-muted-foreground">Access your favorite locations</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground ml-auto" />
              </CardContent>
            </Card>
            
            <Card className="hover:bg-secondary/50 transition-colors cursor-pointer" onClick={() => navigate("/settings")}>
              <CardContent className="p-6 flex items-center gap-4">
                <Settings className="h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-semibold text-primary">Settings</h3>
                  <p className="text-sm text-muted-foreground">Update your preferences</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground ml-auto" />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Dialog open={isModifyDialogOpen} onOpenChange={setIsModifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modify Reservation</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">{upcomingReservation.mall} - Spot {upcomingReservation.spot}</span>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Time</label>
              <select 
                className="w-full px-3 py-2 border rounded-md"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
              >
                <option value="10:00 - 12:00">10:00 - 12:00</option>
                <option value="12:00 - 14:00">12:00 - 14:00</option>
                <option value="14:00 - 16:00">14:00 - 16:00</option>
                <option value="16:00 - 18:00">16:00 - 18:00</option>
              </select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsModifyDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleModifyReservation}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isFindParkingDialogOpen} onOpenChange={setIsFindParkingDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Find Parking Spot</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">{selectedMall}</span>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Time</label>
              <select 
                className="w-full px-3 py-2 border rounded-md"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
              >
                <option value="10:00 - 12:00">10:00 - 12:00</option>
                <option value="12:00 - 14:00">12:00 - 14:00</option>
                <option value="14:00 - 16:00">14:00 - 16:00</option>
                <option value="16:00 - 18:00">16:00 - 18:00</option>
              </select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsFindParkingDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleConfirmParking}>
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dashboard;
