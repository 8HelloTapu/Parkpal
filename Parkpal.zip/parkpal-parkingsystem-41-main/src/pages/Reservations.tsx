
import { useState } from "react";
import { Search, Calendar, Clock, MapPin, Filter, RotateCcw, Navigation, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import DashboardSidebar from "@/components/DashboardSidebar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
  DialogOverlay
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

const reservations = [
  {
    id: "RES-001",
    mall: "Central Mall",
    zone: "A",
    spot: "123",
    date: "2024-03-20",
    time: "14:00 - 16:00",
    status: "upcoming",
    address: "123 Central Mall Road, City Center",
  },
  {
    id: "RES-002",
    mall: "Westfield Shopping",
    zone: "B",
    spot: "456",
    date: "2024-03-21",
    time: "10:00 - 12:00",
    status: "upcoming",
    address: "456 Westfield Avenue, Shopping District",
  },
  {
    id: "RES-003",
    mall: "City Plaza",
    zone: "C",
    spot: "789",
    date: "2024-03-15",
    time: "13:00 - 15:00",
    status: "completed",
    address: "789 Plaza Street, Downtown",
  },
  {
    id: "RES-004",
    mall: "Central Mall",
    zone: "D",
    spot: "101",
    date: "2024-03-10",
    time: "11:00 - 13:00",
    status: "cancelled",
    address: "123 Central Mall Road, City Center",
  },
];

const Reservations = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [selectedReservation, setSelectedReservation] = useState<typeof reservations[0] | null>(null);
  const [modifyDialogOpen, setModifyDialogOpen] = useState(false);
  const [viewDetailsDialogOpen, setViewDetailsDialogOpen] = useState(false);
  const { toast } = useToast();

  const filteredReservations = reservations.filter((reservation) => {
    const matchesStatus = activeTab === "all" ? true : reservation.status === activeTab;
    const matchesSearch = reservation.mall
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesDate = !dateFilter || reservation.date === dateFilter;
    return matchesStatus && matchesSearch && matchesDate;
  });

  const handleModifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReservation) return;

    const formData = new FormData(e.target as HTMLFormElement);
    const newDate = formData.get('date') as string;
    const newTime = formData.get('time') as string;

    console.log('Updating reservation:', {
      id: selectedReservation.id,
      date: newDate,
      time: newTime,
    });

    toast({
      title: "Reservation Modified",
      description: "Your reservation has been successfully updated.",
    });

    setModifyDialogOpen(false);
  };

  const handleCancel = (reservationId: string) => {
    console.log('Cancelling reservation:', reservationId);
    toast({
      title: "Reservation Cancelled",
      description: "Your reservation has been cancelled successfully.",
    });
  };

  const handleRebook = (reservation: typeof reservations[0]) => {
    console.log('Rebooking reservation:', reservation);
    toast({
      title: "Quick Booking Started",
      description: "We've pre-filled the booking form with your previous reservation details.",
    });
  };

  const handleGetDirections = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-transparent">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <Calendar className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            My Reservations
          </h1>
        </div>
      </div>

      <DashboardSidebar />

      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search reservations..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-4">
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-[180px]"
              />
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList>
              <TabsTrigger value="all" onClick={() => setActiveTab("all")}>
                All
              </TabsTrigger>
              <TabsTrigger value="upcoming" onClick={() => setActiveTab("upcoming")}>
                Upcoming
              </TabsTrigger>
              <TabsTrigger value="completed" onClick={() => setActiveTab("completed")}>
                Completed
              </TabsTrigger>
              <TabsTrigger value="cancelled" onClick={() => setActiveTab("cancelled")}>
                Cancelled
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {filteredReservations.map((reservation, index) => (
                      <div key={reservation.id}>
                        {index > 0 && <Separator className="my-4" />}
                        <div className="flex justify-between items-center">
                          <div className="space-y-2">
                            <h3 className="font-semibold text-primary text-lg">
                              {reservation.mall}
                            </h3>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                <span>Zone {reservation.zone} - Spot {reservation.spot}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span>{reservation.date}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                <span>{reservation.time}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="outline"
                                  onClick={() => setSelectedReservation(reservation)}
                                >
                                  View Details
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="bg-white/95 backdrop-blur-sm border-0 shadow-lg">
                                <DialogHeader>
                                  <DialogTitle>Reservation Details</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <h4 className="font-medium">Reservation ID</h4>
                                    <p className="text-sm text-muted-foreground">{reservation.id}</p>
                                  </div>
                                  <div>
                                    <h4 className="font-medium">Mall</h4>
                                    <p className="text-sm text-muted-foreground">{reservation.mall}</p>
                                  </div>
                                  <div>
                                    <h4 className="font-medium">Zone & Slot</h4>
                                    <p className="text-sm text-muted-foreground">
                                      Zone {reservation.zone} - Spot {reservation.spot}
                                    </p>
                                  </div>
                                  <div>
                                    <h4 className="font-medium">Date & Time</h4>
                                    <p className="text-sm text-muted-foreground">
                                      {reservation.date} | {reservation.time}
                                    </p>
                                  </div>
                                  <div>
                                    <h4 className="font-medium">Status</h4>
                                    <p className="text-sm text-muted-foreground capitalize">
                                      {reservation.status}
                                    </p>
                                  </div>
                                  <Button 
                                    className="w-full mt-4"
                                    onClick={() => handleGetDirections(reservation.address)}
                                  >
                                    <Navigation className="w-4 h-4 mr-2" />
                                    Get Directions
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>

                            {reservation.status === "upcoming" && (
                              <>
                                <Dialog open={modifyDialogOpen} onOpenChange={setModifyDialogOpen}>
                                  <DialogTrigger asChild>
                                    <Button 
                                      variant="outline"
                                      onClick={() => setSelectedReservation(reservation)}
                                    >
                                      Modify
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="bg-white/95 backdrop-blur-sm border-0 shadow-lg">
                                    <DialogHeader className="space-y-4">
                                      <DialogTitle className="text-2xl font-semibold text-primary">
                                        Modify Reservation
                                      </DialogTitle>
                                      <DialogDescription className="text-muted-foreground">
                                        Update your reservation details below
                                      </DialogDescription>
                                    </DialogHeader>
                                    {selectedReservation && (
                                      <form onSubmit={handleModifySubmit} className="space-y-6">
                                        <div className="bg-secondary/50 p-6 rounded-lg space-y-3">
                                          <h3 className="text-lg font-semibold text-primary">
                                            {selectedReservation.mall}
                                          </h3>
                                          <div className="space-y-2 text-sm text-muted-foreground">
                                            <div className="flex items-center gap-2">
                                              <MapPin className="h-4 w-4" />
                                              <p>{selectedReservation.address}</p>
                                            </div>
                                            <div className="flex items-center gap-2">
                                              <MapPin className="h-4 w-4" />
                                              <p>Zone {selectedReservation.zone} - Spot {selectedReservation.spot}</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-6">
                                          <div className="space-y-2">
                                            <label className="text-sm font-medium">
                                              Date
                                            </label>
                                            <Input
                                              name="date"
                                              type="date"
                                              defaultValue={selectedReservation.date}
                                              className="w-full bg-secondary/30 border-secondary"
                                            />
                                          </div>
                                          <div className="space-y-2">
                                            <label className="text-sm font-medium">
                                              Time
                                            </label>
                                            <Select name="time" defaultValue={selectedReservation.time}>
                                              <SelectTrigger className="bg-secondary/30 border-secondary">
                                                <SelectValue placeholder="Select time" />
                                              </SelectTrigger>
                                              <SelectContent>
                                                <SelectItem value="10:00 - 12:00">10:00 - 12:00</SelectItem>
                                                <SelectItem value="12:00 - 14:00">12:00 - 14:00</SelectItem>
                                                <SelectItem value="14:00 - 16:00">14:00 - 16:00</SelectItem>
                                                <SelectItem value="16:00 - 18:00">16:00 - 18:00</SelectItem>
                                              </SelectContent>
                                            </Select>
                                          </div>
                                        </div>
                                        <div className="flex justify-end gap-3 pt-4">
                                          <Button
                                            type="button"
                                            variant="outline"
                                            onClick={() => setModifyDialogOpen(false)}
                                            className="bg-transparent hover:bg-secondary/50"
                                          >
                                            Cancel
                                          </Button>
                                          <Button 
                                            type="submit"
                                            className="bg-green-600 hover:bg-green-700 text-white"
                                          >
                                            Save Changes
                                          </Button>
                                        </div>
                                      </form>
                                    )}
                                  </DialogContent>
                                </Dialog>
                                <Button 
                                  variant="destructive"
                                  onClick={() => handleCancel(reservation.id)}
                                >
                                  Cancel
                                </Button>
                              </>
                            )}

                            {reservation.status === "completed" && (
                              <Button 
                                variant="outline"
                                onClick={() => handleRebook(reservation)}
                                className="flex items-center gap-2"
                              >
                                <RotateCcw className="h-4 w-4" />
                                Rebook
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Reservations;

