import { Bookmark, BookmarkX, MapPin, X, Car, Clock, Shield, Zap, Accessibility, Heart, Baby } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import DashboardSidebar from "@/components/DashboardSidebar";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useState } from "react";

const initialSavedMalls = [
  {
    id: 1,
    name: "Central Mall",
    lastVisited: "2024-03-15",
    address: "123 Main Street, City Center",
    parkingSpots: 150,
    status: "Available",
    isBookmarked: true,
  },
  {
    id: 2,
    name: "WhiteField Shopping",
    lastVisited: "2024-03-14",
    address: "456 Park Avenue, WhiteField",
    parkingSpots: 200,
    status: "Limited",
    isBookmarked: true,
  },
  {
    id: 3,
    name: "Sarath City Capital Mall",
    lastVisited: "2024-03-13",
    address: "789 Market Street, Sarath City",
    parkingSpots: 300,
    status: "Full",
    isBookmarked: true,
  },
];

const SavedMalls = () => {
  const { toast } = useToast();
  const [selectedMall, setSelectedMall] = useState<typeof initialSavedMalls[0] | null>(null);
  const [savedMalls, setSavedMalls] = useState(initialSavedMalls);

  const handleRemove = (mallId: number) => {
    setSavedMalls(prevMalls => prevMalls.filter(mall => mall.id !== mallId));
    toast({
      title: "Mall Removed",
      description: "The mall has been removed from your saved list.",
    });
  };

  const handleReservation = (mallId: number) => {
    toast({
      title: "Booking Initiated",
      description: "Please complete your parking spot reservation.",
    });
  };

  const toggleBookmark = (mallId: number) => {
    const mall = savedMalls.find(m => m.id === mallId);
    
    if (mall?.isBookmarked) {
      setSavedMalls(prevMalls => prevMalls.filter(m => m.id !== mallId));
      toast({
        title: "Mall Unbookmarked",
        description: "The mall has been removed from your saved list.",
      });
    } else {
      setSavedMalls(prevMalls =>
        prevMalls.map(m =>
          m.id === mallId ? { ...m, isBookmarked: true } : m
        )
      );
      toast({
        title: "Mall Bookmarked",
        description: "The mall has been added to your bookmarks.",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "available":
        return "text-green-600";
      case "limited":
        return "text-yellow-600";
      case "full":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <Bookmark className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Saved Malls
          </h1>
        </div>
      </div>

      <DashboardSidebar />

      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto space-y-8">
          {savedMalls.map((mall) => (
            <Card key={mall.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-semibold text-primary flex items-center gap-2">
                      <button 
                        onClick={() => toggleBookmark(mall.id)}
                        className="hover:scale-110 transition-transform"
                      >
                        {mall.isBookmarked ? (
                          <Bookmark className="h-5 w-5 text-primary" />
                        ) : (
                          <BookmarkX className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                      {mall.name}
                    </h3>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <span>{mall.address}</span>
                      </div>
                      <div>Available Parking Spots: {mall.parkingSpots}</div>
                      <div className={`font-medium ${getStatusColor(mall.status)}`}>
                        Status: {mall.status}
                      </div>
                      <div className="text-muted-foreground">
                        Last Visited: {mall.lastVisited}
                      </div>
                    </div>
                  </div>
                  <div className="space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => handleRemove(mall.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      Remove
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>Reserve Parking</Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                        <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none">
                          <X className="h-4 w-4" />
                          <span className="sr-only">Close</span>
                        </DialogClose>
                        <DialogHeader>
                          <DialogTitle>{mall.name}</DialogTitle>
                          <DialogDescription>{mall.address}</DialogDescription>
                        </DialogHeader>
                        
                        <div className="grid gap-6">
                          <div>
                            <h4 className="font-medium mb-2">Parking Layout</h4>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="bg-secondary p-4 rounded-lg text-center">
                                <div className="text-lg font-semibold">Zone A</div>
                                <div className="text-sm text-muted-foreground">
                                  30/50 spots
                                </div>
                              </div>
                              <div className="bg-secondary p-4 rounded-lg text-center">
                                <div className="text-lg font-semibold">Zone B</div>
                                <div className="text-sm text-muted-foreground">
                                  45/60 spots
                                </div>
                              </div>
                              <div className="bg-secondary p-4 rounded-lg text-center">
                                <div className="text-lg font-semibold">Zone C</div>
                                <div className="text-sm text-muted-foreground">
                                  25/40 spots
                                </div>
                              </div>
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-2">Reserved Spots</h4>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="bg-blue-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Accessibility className="h-4 w-4" />
                                  <span>Disabled</span>
                                </div>
                                <div className="text-sm">8 spots</div>
                              </div>
                              <div className="bg-green-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Heart className="h-4 w-4" />
                                  <span>Elderly</span>
                                </div>
                                <div className="text-sm">5 spots</div>
                              </div>
                              <div className="bg-purple-100 p-3 rounded-lg text-center">
                                <div className="font-medium flex items-center justify-center gap-2">
                                  <Baby className="h-4 w-4" />
                                  <span>Pregnant</span>
                                </div>
                                <div className="text-sm">3 spots</div>
                              </div>
                            </div>
                          </div>

                          <form className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <label className="text-sm font-medium">Date</label>
                                <Input type="date" className="w-full" />
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-medium">Time</label>
                                <Input type="time" className="w-full" />
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Vehicle Type</label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select vehicle type" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="2-wheeler">2 Wheeler</SelectItem>
                                  <SelectItem value="4-wheeler">4 Wheeler</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="space-y-2">
                              <label className="text-sm font-medium">Special Requirements</label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select if needed" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="disabled">Disabled Parking</SelectItem>
                                  <SelectItem value="elderly">Elderly Parking</SelectItem>
                                  <SelectItem value="pregnant">Pregnant Parking</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            <Button 
                              className="w-full"
                              onClick={() => handleReservation(mall.id)}
                            >
                              Reserve Spot
                            </Button>
                          </form>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default SavedMalls;
