
import { Bell, Tag, Clock, AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import DashboardSidebar from "@/components/DashboardSidebar";

const recentNotifications = [
  {
    id: 1,
    type: "reminder",
    message: "Your parking at Central Mall expires in 30 minutes",
    time: "Just now",
    icon: Clock
  },
  {
    id: 2,
    type: "ad",
    message: "Weekend Special: Get 20% off on 4-hour parking at WhiteField Shopping",
    time: "2 hours ago",
    icon: Tag
  },
  {
    id: 3,
    type: "offer",
    message: "Early bird parking offer: 50% off before 9 AM at Central Mall",
    time: "3 hours ago",
    icon: Tag
  },
  {
    id: 4,
    type: "alert",
    message: "High traffic alert at Sarath City Capital Mall",
    time: "4 hours ago",
    icon: AlertCircle
  },
  {
    id: 5,
    type: "ad",
    message: "New restaurants opened at WhiteField Shopping - Visit today!",
    time: "5 hours ago",
    icon: Tag
  }
];

const Notifications = () => {
  const getNotificationStyles = (type: string) => {
    switch (type) {
      case "ad":
        return "bg-purple-50 border-purple-200";
      case "offer":
        return "bg-green-50 border-green-200";
      case "reminder":
        return "bg-blue-50 border-blue-200";
      case "alert":
        return "bg-orange-50 border-orange-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const getNotificationBadge = (type: string) => {
    switch (type) {
      case "ad":
        return <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">Ad</Badge>;
      case "offer":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Offer</Badge>;
      case "reminder":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Reminder</Badge>;
      case "alert":
        return <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">Alert</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <Bell className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Notifications
          </h1>
        </div>
      </div>
      
      <DashboardSidebar />
      
      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold text-primary flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Recent Updates
                </h2>
              </div>
              <div className="space-y-4">
                {recentNotifications.map((notification, index) => (
                  <div key={notification.id}>
                    {index > 0 && <Separator className="my-4" />}
                    <div className={`p-4 rounded-lg border ${getNotificationStyles(notification.type)}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex gap-3">
                          <notification.icon className="h-5 w-5 mt-1 flex-shrink-0" />
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {getNotificationBadge(notification.type)}
                            </div>
                            <p className="text-muted-foreground">{notification.message}</p>
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground whitespace-nowrap ml-4">{notification.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Notifications;
