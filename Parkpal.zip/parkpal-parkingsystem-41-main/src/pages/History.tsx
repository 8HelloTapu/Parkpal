
import { useState } from "react";
import { 
  Calendar,
  Clock, 
  MapPin,
  History as HistoryIcon,
  ChartBar
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import DashboardSidebar from "@/components/DashboardSidebar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

// Sample data - in a real app, this would come from an API
const parkingHistory = [
  {
    id: 1,
    mall: "Central Mall",
    spot: "A-123",
    date: "2024-03-15",
    time: "14:00 - 16:00",
  },
  {
    id: 2,
    mall: "WhiteField Shopping",
    spot: "B-456",
    date: "2024-03-14",
    time: "10:00 - 12:00",
  },
  {
    id: 3,
    mall: "Sarath City Capital Mall",
    spot: "C-789",
    date: "2024-03-13",
    time: "13:00 - 15:00",
  },
];

// Sample analytics data
const analyticsData = [
  { month: 'Jan', visits: 4 },
  { month: 'Feb', visits: 6 },
  { month: 'Mar', visits: 8 },
  { month: 'Apr', visits: 5 },
  { month: 'May', visits: 7 },
  { month: 'Jun', visits: 9 },
];

const History = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  const filteredHistory = parkingHistory.filter((record) => {
    const matchesSearch = record.mall
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesDate = !dateFilter || record.date === dateFilter;
    return matchesSearch && matchesDate;
  });

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-primary py-8 px-20">
        <div className="flex items-center gap-3 ml-8">
          <HistoryIcon className="h-8 w-8 text-white" />
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Parking History
          </h1>
        </div>
      </div>

      <DashboardSidebar />

      <main className="px-8 py-6 ml-16 mt-16">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center">
            <div className="relative flex-1">
              <Input
                type="search"
                placeholder="Search by mall name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-4">
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-[180px]"
              />
            </div>
          </div>

          <Tabs defaultValue="history" className="w-full">
            <TabsList>
              <TabsTrigger value="history">Parking History</TabsTrigger>
              <TabsTrigger value="analytics">Usage Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="history">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {filteredHistory.map((record) => (
                      <div key={record.id} className="border-b pb-6 last:border-b-0 last:pb-0">
                        <div className="space-y-2">
                          <h3 className="font-semibold text-lg">
                            {record.mall}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              <span>Spot {record.spot}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>{record.date}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>{record.time}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <ChartBar className="h-5 w-5" />
                        Monthly Parking Usage
                      </h3>
                    </div>
                    <div className="h-[400px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={analyticsData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="visits" fill="#3b82f6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default History;
