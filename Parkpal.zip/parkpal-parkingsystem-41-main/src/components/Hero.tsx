
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Hero = () => {
  const navigate = useNavigate();

  return (
    <section className="min-h-[90vh] flex flex-col items-center justify-center px-4 py-16 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse delay-700" />
      </div>

      <div className="w-full max-w-4xl mx-auto text-center z-10 animate-fade-in">
        <h1 
          className="text-6xl font-bold mb-8 tracking-tight text-primary animate-fade-in group cursor-pointer transition-all duration-300 hover:scale-105"
          onClick={() => navigate('/')}
        >
          ParkPal
          <div className="w-24 h-1 bg-primary mx-auto mt-2 rounded-full transition-all duration-300 group-hover:w-32 group-hover:bg-accent" />
        </h1>
        <span className="inline-block px-4 py-2 mb-6 text-sm font-medium tracking-wider text-primary bg-primary/10 rounded-full hover:bg-primary/20 transition-colors duration-300">
          PARKING MADE SIMPLE
        </span>
        <h2 className="mb-6 text-4xl font-bold tracking-tight text-[#1A1F2C] sm:text-6xl animate-fade-in">
          Find Your Perfect{" "}
          <span className="text-primary">Parking Spot</span>
        </h2>
        <p className="max-w-2xl mx-auto mb-8 text-lg text-gray-600 animate-fade-in">
          Effortlessly find and reserve parking at your favorite malls with ParkPal.
          Experience hassle-free parking like never before.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in">
          <Button
            size="lg"
            className="px-8 py-6 text-lg font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg bg-primary hover:bg-primary/90 w-full sm:w-auto"
            onClick={() => navigate("/signup")}
          >
            Get Started
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
