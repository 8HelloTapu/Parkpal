
import { Phone, Mail, Facebook, Twitter, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="py-16 bg-white/50 backdrop-blur-sm">
      <div className="container px-4 mx-auto">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="mb-6 text-2xl font-bold tracking-tight text-[#1A1F2C]">
            We're Here to <span className="text-primary">Help</span>
          </h2>
          <p className="mb-8 text-gray-600">
            Got a question? Our dedicated customer support team is always ready to
            assist you. Reach out via email, phone, or social media for fast and helpful service.
            We've got your back.
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-primary hover:text-white transition-colors border-primary/50 hover:border-primary"
              onClick={() => window.location.href = "tel:+1234567890"}
              aria-label="Call us"
            >
              <Phone className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-primary hover:text-white transition-colors border-primary/50 hover:border-primary"
              onClick={() => window.location.href = "mailto:support@parkpal.com"}
              aria-label="Email us"
            >
              <Mail className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-primary hover:text-white transition-colors border-primary/50 hover:border-primary"
              onClick={() => window.open("https://facebook.com/parkpal", "_blank")}
              aria-label="Visit our Facebook page"
            >
              <Facebook className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-primary hover:text-white transition-colors border-primary/50 hover:border-primary"
              onClick={() => window.open("https://twitter.com/parkpal", "_blank")}
              aria-label="Visit our Twitter profile"
            >
              <Twitter className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-primary hover:text-white transition-colors border-primary/50 hover:border-primary"
              onClick={() => window.open("https://instagram.com/parkpal", "_blank")}
              aria-label="Visit our Instagram profile"
            >
              <Instagram className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
