
import { useState, useEffect, useRef } from "react";
import { Home, CalendarDays, Map, Settings, History, Bell, BookMarked, LogOut, Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation, Link, useNavigate } from "react-router-dom";

const menuItems = [
  { icon: Home, label: "Overview", href: "/dashboard" },
  { icon: CalendarDays, label: "My Reservations", href: "/reservations" },
  { icon: Map, label: "Mall Listings", href: "/mall-listings" },
  { icon: BookMarked, label: "Saved Malls", href: "/saved-malls" },
  { icon: History, label: "History", href: "/history" },
  { icon: Bell, label: "Notifications", href: "/notifications" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

const DashboardSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sidebarRef.current && 
        !sidebarRef.current.contains(event.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    navigate('/');
  };

  return (
    <>
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 p-2 rounded-lg bg-primary hover:bg-primary/90 text-white flex items-center gap-2"
      >
        <Menu className="h-6 w-6" />
      </button>

      <aside
        ref={sidebarRef}
        className={cn(
          "fixed top-0 left-0 h-full bg-white border-r border-gray-200 shadow-lg transition-transform duration-300 ease-in-out z-40 w-64",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="p-6 flex items-center gap-6 border-b border-gray-100">
          <Menu className="h-6 w-6 text-primary" />
          <span className="text-xl font-semibold text-primary">ParkPal</span>
        </div>

        <nav className="py-4 flex flex-col h-[calc(100%-80px)]">
          <div className="flex-1">
            {menuItems.map((item) => (
              <Link
                key={item.label}
                to={item.href}
                className={cn(
                  "flex items-center gap-3 mx-4 px-3 py-2.5 my-1 text-gray-700 rounded-lg hover:bg-secondary transition-colors",
                  location.pathname === item.href && "bg-secondary text-primary font-medium"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          <div className="px-4 pb-4">
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 px-3 py-2.5 my-1 text-gray-700 rounded-lg hover:bg-secondary transition-colors w-full"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </button>
          </div>
        </nav>
      </aside>
    </>
  );
};

export default DashboardSidebar;
