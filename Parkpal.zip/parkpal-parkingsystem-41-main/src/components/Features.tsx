
import { Card } from "@/components/ui/card";
import {
  Search,
  MapPin,
  Calendar,
  Navigation,
  Clock,
  History,
  Bell,
  Settings,
} from "lucide-react";

const features = [
  {
    icon: Search,
    title: "Smart Mall Selection",
    description:
      "Browse through a vast list of malls in your area—complete with real-time availability and parking fees.",
  },
  {
    icon: MapPin,
    title: "Search & Filter",
    description:
      "Find your ideal mall in seconds with a powerful search engine. Filter by name, location, amenities, or parking options.",
  },
  {
    icon: Calendar,
    title: "Reserve Your Spot",
    description:
      "No more stress when you're heading to the mall. Reserve your parking spot in advance with no upfront payment required!",
  },
  {
    icon: Navigation,
    title: "Navigate with Ease",
    description:
      "Seamlessly integrated with Google Maps, our app provides turn-by-turn directions to your reserved parking spot.",
  },
  {
    icon: Clock,
    title: "Manage Your Reservations",
    description:
      "Change plans? No problem. Modify or cancel your reservation in a few taps. We make managing your parking easy.",
  },
  {
    icon: History,
    title: "Parking History & Insights",
    description:
      "Track your parking history, review past reservations, and gain valuable insights into your parking habits.",
  },
  {
    icon: Bell,
    title: "Stay Informed",
    description:
      "Get real-time notifications about your reservation status, changes, and updates. You'll always be in the know.",
  },
  {
    icon: Settings,
    title: "Tailor Your Experience",
    description:
      "Customize every aspect of your parking experience. We've got you covered with personalized options.",
  },
];

const Features = () => {
  return (
    <section className="py-24 bg-white/50 backdrop-blur-sm">
      <div className="container px-4 mx-auto">
        <div className="max-w-2xl mx-auto mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-[#1A1F2C] sm:text-4xl">
            Features of <span className="text-primary">ParkPal</span>
          </h2>
          <p className="text-gray-600">
            Everything you need to make your parking experience seamless and stress-free.
          </p>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="p-6 transition-all duration-300 bg-white/80 hover:bg-white border-primary/10 hover:border-primary/30 hover:shadow-lg hover:-translate-y-1 backdrop-blur-sm animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <feature.icon className="w-12 h-12 p-2 mb-4 text-primary bg-primary/10 rounded-xl" />
              <h3 className="mb-2 text-xl font-semibold text-[#1A1F2C]">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
